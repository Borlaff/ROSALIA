import rosalia as rs
import os
import numpy as np
import pandas as pd
from astropy import constants as const
import astropy.units as u
from astropy.units import Quantity

def f_hst_attenuation(theta):
    return(10**f_hst_attenuation_interpolator(np.log10(theta)))

##############


def sort_hst_flcs_by_filter(filelist):
    filters_list_keywords = rs.utils.get_keys_from_header(filelist, ["FILTER1", "FILTER2"], ext=0)
    filters = []
    for i in tqdm(range(len(filelist))):
        if not "CLEAR" in filters_list_keywords[0][i]:
            exposure_filter = filters_list_keywords[0][i]
        elif not "CLEAR" in filters_list_keywords[1][i]:
            exposure_filter = filters_list_keywords[1][i]
        else:
            exposure_filter = "None"
        filters.append(exposure_filter)

    list_of_filters = np.array(list(set(filters)))
    filters = np.array(filters)

    for filter_name in tqdm(list_of_filters):
        os.system("mkdir " + filter_name)
        exposures_with_that_filter = np.array(filelist)[np.where(filters == filter_name)[0]]

        if filter_name != "None":
            for selected_exposure in exposures_with_that_filter:
                os.system("mv " + selected_exposure + " " + filter_name)


    return(list_of_filters)
#####################################################################


def measure_sky_level_HST_ACS(exposure_name, verbose=False):
    # Open the fits file
    from astropy.io import fits

    exposure_fits = fits.open(exposure_name, memmap=True) # We open the fits file with astropy

    # Try to retrieve a previous analysis that was performed in this exposure
    try:
        return({"zody": exposure_fits[1].header["ZODY"],
                "sky":  exposure_fits[1].header["SKYLVL"]})

    except:
        if verbose: print("No previous sky-zody analysis available in this header.")


    # Get the basic parameters
    PHOTPLAM =  exposure_fits[1].header["PHOTPLAM"] # / Pivot wavelength (Angstroms)   <---- This is the observation wavelength. We will use this to estimate the Zodiacal light.
    PHOTFLAM =  exposure_fits[1].header["PHOTFLAM"] # / inverse sensitivity, ergs/cm2/Ang/electron   <---- This is the transformation between electrons to flux. We will use this to turn the e/s/px to Jy/arcsec2.
    RA_TARG  = exposure_fits[0].header["RA_TARG"]    #  Right ascension of the observation target .
    DEC_TARG = exposure_fits[0].header["DEC_TARG"]  #  Declination of the observation target
    EXPSTART = exposure_fits[0].header["EXPSTART"]  #  Time of the observation, in Modified Julian Date
    # Get the right filter
    filter_1 = exposure_fits[0].header["FILTER1"]
    filter_2 = exposure_fits[0].header["FILTER2"]

    if "CLEAR" in filter_1:
        filter_name = filter_2
    else:
        filter_name = filter_1


    # Lets import some more astropy packages to deal with the time, units, and coordinates.

    # -------------------------------------- #
    # MODEL ZODIACAL LIGHT                   #
    # -------------------------------------- #
    # Initialize a zodiacal light model at a wavelength/frequency or over a bandpass
    zody_background_sci1 = rs.sky.get_zodiacal_background(input_name=exposure_name, ext=1,
                                                          wavelength=filter_name,
                                                          telescope="HST",
                                                          instrument="ACS",
                                                          detector="WFC",
                                                          expstart=EXPSTART,
                                                          step=4000, zody_mode="zodipy",
                                                          nbins_wavelength=20, obslocin=3,
                                                          grid_method="random", verbose=False, interpolate=False)
    import bottleneck as bn
    median_zody_jy_arcsec2 = bn.nanmedian(zody_background_sci1)

    sky_sci1 = rs.sky.correct_flat_sky(input_name=exposure_name, ext=1, overwrite=False, clean=True, verbose=False)
    median_sky_es = sky_sci1["skylvl"]
    # print(median_sky_es)
    median_sky_jy_arcsec2 = rs.detectors.HST_ACS_counts_to_jy(flux_ACS=median_sky_es, photflam=PHOTFLAM, photplam=PHOTPLAM)

    if not np.isnan(median_sky_jy_arcsec2):    exposure_fits[1].header["SKYLVL"] = median_sky_jy_arcsec2
    if not np.isnan(median_zody_jy_arcsec2):    exposure_fits[1].header["ZODY"]   = median_zody_jy_arcsec2

    exposure_fits.verify("silentfix")
    exposure_fits.writeto(exposure_name, overwrite=True)
    exposure_fits.close()

    return({"zody": median_zody_jy_arcsec2, "sky": median_sky_jy_arcsec2})



def hst_estimate_straylight_SCA(
            wcs, 
            filter,
            catalog,
            instrument,
            verbose=True):

    # Make the detector grid
    detector_grid = rs.detectors.make_detector_grid(wcs, step=200, mode="random")
    ra_detector = detector_grid["grid_world"][0]
    dec_detector = detector_grid["grid_world"][1]

    # Get the stars
    sep_angle_dict = rs.utils.separation_and_position_angle(ra1=ra_detector, dec1=dec_detector,
                                                            ra2=np.array(catalog["ra"]), dec2=np.array(catalog["dec"]))
    star_dist = sep_angle_dict["distance"]
    star_pa = sep_angle_dict["position_angle"]

    # Load HST NDI function. 
    ndi_db = pd.read_csv(os.environ["ROSALIACACHE"] + "/CORE/NDI/HST/ndi_HST_legacy_bely2003.csv")
    pixsize = rs.telescopes.Hubble.get_physical_pixelsize(instrument)

    # Make the NDI conversion 
    lambda_max = filter["filter_lambda_max"].to("m").value
    lambda_min = filter["filter_lambda_min"].to("m").value
    lambda_ref = filter["filter_lambda_ref"].to("m").value
    transmission = filter["filter_transmission_ref"]

    mag = np.array(catalog["mag_lambda"])
    irradiance_stars = const.c*(lambda_max-lambda_min)/(lambda_ref**2)*((10**(-0.4*(mag+56.1)))*u.W/u.meter**2/u.Hz)

    NDI_conversion_factor = ((pixsize**2)*transmission*lambda_ref/const.c/const.h)
    NDI_transfer_function = np.interp(x=star_dist, xp=np.array(ndi_db["theta"]), fp=np.array(ndi_db["NDI"]), right=0)
    

    straylight_lvl = np.zeros(len(ra_detector))

    for i in range(NDI_transfer_function.shape[0]):
        straylight_lvl[i] = np.nansum((NDI_transfer_function[i,:]*NDI_conversion_factor*irradiance_stars).decompose()).value

    return(ra_detector, dec_detector, straylight_lvl)


 

def hst_conversion_mjysr(photflam, photplam, pixscale):
    '''Estimates the conversion factor between counts/s and MJy/sr for HST/ACS level 2 images.
    
    Based on: https://www.stsci.edu/hst/instrumentation/acs/data-analysis/zeropoints
    
    Parameters
    ----------
    photflam : astropy.units.quantity.Quantity
        Inverse sensitivity in units of erg cm^-2 Å^-1 electron^-1.
        This represents the scaling factor to transform instrumental flux 
        (electrons/s) to physical flux density.
        
    photplam : astropy.units.quantity.Quantity
        Pivot wavelength in Angstroms (Å).
        
    pixscale : astropy.units.quantity.Quantity
        Angular size of the detector pixel in arcseconds.
    
    Returns
    -------
    conversion_mjysr : astropy.units.quantity.Quantity
        Multiplicative conversion factor in units of MJy s / sr.
        Multiply your count rate (counts/s) by this factor to get MJy/sr.
        
    Examples
    --------
    >>> import astropy.units as u
    >>> photflam = 7.87e-20 * u.erg / u.cm**2 / u.AA
    >>> photplam = 5907.38 * u.AA
    >>> pixscale = 0.05 * u.arcsec
    >>> factor = hst_conversion_mjysr(photflam, photplam, pixscale)
    '''

    # Validate inputs are Quantity objects

    if not all(isinstance(x, Quantity) for x in [photflam, photplam, pixscale]):
        raise TypeError("All inputs must be astropy Quantity objects with units")
    
    # Validate units are compatible
    try:
        photflam.to(u.erg / u.cm**2 / u.AA)
        photplam.to(u.AA)
        pixscale.to(u.arcsec)
    except u.UnitConversionError as e:
        raise ValueError(f"Input units are incompatible: {e}")

    conversion_mjysr = (((photplam**2/const.c * (photflam)))/(pixscale**2)).decompose().to("MJy s / sr")
    return(conversion_mjysr)


